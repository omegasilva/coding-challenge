import React, { createContext, useState, ReactNode, useContext } from 'react';

interface DivsContextType {
  divs: number[];
  removeFirstAddLast: () => void;
}

const DivsContext = createContext<DivsContextType | undefined>(undefined);

interface DivsProviderProps {
  children: ReactNode;
}

const DivsProvider: React.FC<DivsProviderProps> = ({ children }) => {
  let divs = [1, 2, 3, 4, 5];

  const removeFirstAddLast = () => {
    const newDivs = divs.slice(1);
    newDivs.push(divs.length + 1);
    return newDivs;
  };

  return (
    <DivsContext.Provider value={{ divs, removeFirstAddLast }}>
      {children}
    </DivsContext.Provider>
  );
};

const useDivsContext = () => {
  const context = useContext(DivsContext);
  if (!context) {
    throw new Error('useDivsContext must be used within a DivsProvider');
  }
  return context;
};

export { DivsProvider, useDivsContext };
