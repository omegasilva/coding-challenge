import React, { createContext, useState, ReactNode, useContext } from 'react';

interface DivsContextType {
  divs: number[];
  removeFirstAddLast: () => void;
}

const DivsContext = createContext<DivsContextType | undefined>(undefined);

interface DivsProviderProps {
  children: ReactNode;
}

const DivsProvider: React.FC<DivsProviderProps> = ({ children }) => {
  const [divs, setDivs] = useState<number[]>([1, 2, 3, 4, 5]);

  const removeFirstAddLast = () => {
    setDivs(prevDivs => {
      const newDivs = prevDivs.slice(1);
      newDivs.push(prevDivs.length + 1);
      return newDivs;
    });
  };

  return (
    <DivsContext.Provider value={{ divs, removeFirstAddLast }}>
      {children}
    </DivsContext.Provider>
  );
};

const useDivsContext = () => {
  const context = useContext(DivsContext);
  if (!context) {
    throw new Error('useDivsContext must be used within a DivsProvider');
  }
  return context;
};

export { DivsProvider, useDivsContext };
