import React from 'react';
import { DivsProvider, useDivsContext } from './DivsContext';
import './App.css';

const DivsDisplay: React.FC = () => {
  const { divs, removeFirstAddLast } = useDivsContext();

  return (
    <div className="container">
      <div className="divs">
        {divs.map((num, index) => (
          <div key={index} className="div-item">{num}</div>
        ))}
      </div>
      <button onClick={removeFirstAddLast} className="action-button">Remove First & Add Last</button>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <DivsProvider>
      <div className="App">
        <h1>Simple Div Manager</h1>
        <DivsDisplay />
      </div>
    </DivsProvider>
  );
};

export default App;