import React, { createContext } from 'react';

const DivsContext = createContext();

const DivsProvider = ({ children }) => {
  let divs = [1, 2, 3, 4, 5];

  const removeFirstAddLast = () => {
      const newDivs = divs.slice(1);
      newDivs.push(divs.length + 1);
      return newDivs;
  };

  return (
    <DivsContext.Provider value={{ divs, removeFirstAddLast }}>
      {children}
    </DivsContext.Provider>
  );
};

export { DivsContext, DivsProvider };
