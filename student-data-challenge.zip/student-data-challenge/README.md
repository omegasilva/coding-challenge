### Coding Challenge

Following are the objectives you need to achieve:

1. The file `data/Students.js` contains a data set for students and examination scores. Display this data in a table.
2. Filter the table based on the letter selected from the drop down. If the drop down option is `Select Starting Letter` all the data must be displayed.
3. Calculate the average of the examination scores for each of the subjects.
