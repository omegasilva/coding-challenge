import { createContext, useState } from "react";

const StudentsContext = createContext();

const StudentsProvider = ({children}) => {
    const students = {};

    const filterStudents = (letter) => {

    }

    return (
        <StudentsContext.Provider value={{students, filterStudents}}>
            {children}
        </StudentsContext.Provider>
    );
}

export {StudentsContext, StudentsProvider};