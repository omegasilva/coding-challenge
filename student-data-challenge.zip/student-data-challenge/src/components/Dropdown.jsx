import React from 'react';

const Dropdown = ({ selectedLetter, handleFilterChange }) => {
  return (
    <div className="dropdown-container">
      <label>Filter by Starting Letter: </label>
      <select value={selectedLetter} onChange={handleFilterChange} className="dropdown">
        <option value="Select Starting Letter">Select Starting Letter</option>
        <option value="A">A</option>
        <option value="B">B</option>
        <option value="C">C</option>
        <option value="D">D</option>
        <option value="E">E</option>
      </select>
    </div>
  );
};

export default Dropdown;