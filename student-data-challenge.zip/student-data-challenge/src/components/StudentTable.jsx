import React from 'react';
import AverageRow from './AverageRow';

const StudentTable = ({ students }) => {

  return (
    <table className="student-table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Maths Score</th>
          <th>Science Score</th>
        </tr>
      </thead>
      <tbody>
        {students.length > 0 && students.map((student, index) => (
          <tr key={index}>
            <td>{student.name}</td>
            <td>{student.maths}</td>
            <td>{student.science}</td>
          </tr>
        ))}
        <AverageRow/>
      </tbody>
    </table>
  );
};

export default StudentTable;
