import React from 'react';

const AverageRow = () => {
  return (
    <tr className="average-row">
      <td><strong>Average</strong></td>
      <td><strong>?</strong></td>
      <td><strong>?</strong></td>
    </tr>
  );
};

export default AverageRow;
