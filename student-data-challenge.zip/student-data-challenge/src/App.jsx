import React, { useContext, useEffect, useState } from 'react';
import Dropdown from './components/Dropdown';
import StudentTable from './components/StudentTable';
import './App.css';
import { StudentsContext, StudentsProvider } from './StudentsContext';



const AppDisplay = () => {
  const {students, filterStudents} = useContext(StudentsContext);
  
  const [selectedLetter, setSelectedLetter] = useState('Select Starting Letter');

  const handleFilterChange = (e) => {
    setSelectedLetter(e.target.value);
    filterStudents(selectedLetter);
  };

  return (
    <div className="app-container">
      <h2>Student Scores</h2>
      <Dropdown selectedLetter={selectedLetter} handleFilterChange={handleFilterChange} />
      <StudentTable students={students}/>
    </div>
  );
};

const App = () => {
  return (
    <StudentsProvider>
      <AppDisplay />
    </StudentsProvider>
  );
}

export default App;

