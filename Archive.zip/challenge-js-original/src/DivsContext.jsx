import React, { createContext, useState } from 'react';

const DivsContext = createContext();

const DivsProvider = ({ children }) => {
  let [divs, setDivs] = useState([1, 2, 3, 4, 5]);

  const removeFirstAddLast = () => {
    const newDivs = [...divs.slice(1), divs.length + 1];
    setDivs(newDivs);
    // setDivs(prevDivs => {
    //   const newDivs = prevDivs.slice(1);
    //   newDivs.push(prevDivs.length + 1);
    //   return newDivs;
    // });
  };

  return (
    <DivsContext.Provider value={{ divs, removeFirstAddLast }}>
      {children}
    </DivsContext.Provider>
  );
};

export { DivsContext, DivsProvider };
