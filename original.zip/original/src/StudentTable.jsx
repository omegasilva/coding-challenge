import React from 'react';
import AverageRow from './AverageRow';

const StudentTable = ({ students }) => {

  const calculateAverage = (subject) => {
    const total = students.reduce((acc, student) => acc + student[subject], 0);
    return students.length > 0 ? (total / students.length).toFixed(2) : 0;
  };

  return (
    <table className="student-table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Maths Score</th>
          <th>Science Score</th>
        </tr>
      </thead>
      <tbody>
        {students.map((student, index) => (
          <tr key={index}>
            <td>{student.name}</td>
            <td>{student.maths}</td>
            <td>{student.science}</td>
          </tr>
        ))}
        <AverageRow calculateAverage={calculateAverage}/>
      </tbody>
    </table>
  );
};

export default StudentTable;
