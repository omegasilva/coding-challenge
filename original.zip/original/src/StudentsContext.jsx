import { createContext, useState } from "react";
import studentsData from "./Students";

const StudentsContext = createContext();

const StudentsProvider = ({children}) => {
    let [students, setStudents] = useState(studentsData);

    const filterStudents = (letter) => {
        const filteredStudents = studentsData.filter((student) => {
            return letter === "Select Starting Letter" || student.name.startsWith(letter);
        });

        setStudents(filteredStudents);
    }

    return (
        <StudentsContext.Provider value={{students, filterStudents}}>
            {children}
        </StudentsContext.Provider>
    );
}

export {StudentsContext, StudentsProvider};