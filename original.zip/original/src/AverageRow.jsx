import React from 'react';

const AverageRow = ({ calculateAverage }) => {
  return (
    <tr className="average-row">
      <td><strong>Average</strong></td>
      <td><strong>{calculateAverage('maths')}</strong></td>
      <td><strong>{calculateAverage('science')}</strong></td>
    </tr>
  );
};

export default AverageRow;
